// Adaptive Rate Limiting Engine — CMPSBL® Bridge Adapter (Go)
// Context-aware rate limiting that adjusts based on user trust, request complexity, system load, and behavioral patterns
//
// Primitive Chain: ACCESS Layer → ANALYTICS Engine → DEFENSE Layer → IDENTITY Organ
// Category: security | CJPI: 99.7
//
// This is a BRIDGE ADAPTER, not a standalone runtime.
// Runtime logic lives in the canonical TypeScript Mini-Runtime™.
// This adapter routes execution to the canonical runtime when available,
// falling back to deterministic local output when offline.
//
// Integrity: capabilityHash + moduleChainHash validated on every request
// Health: rolling health score governs automatic mode switching
// Degraded: integrity failures are explicit, never silently masked
//
// Canonical Runtime Version: 14.4.1
// © CMPSBL® — All rights reserved.

package adaptive_rate_limiting_engine

import (
	"bytes"
	"encoding/json"
	"fmt"
	"math"
	"net/http"
	"sync"
	"time"
	"crypto/rand"
	encHex "encoding/hex"
)

// BridgeMeta — capability metadata for this bridge adapter
var BridgeMeta = map[string]interface{}{
	"name":              "Adaptive Rate Limiting Engine",
	"cjpi":              99.7,
	"category":          "security",
	"module_chain":      []string{"ACCESS", "ANALYTICS", "DEFENSE", "IDENTITY"},
	"bridge_type":       "hybrid",
	"canonical_version": "14.4.1",
	"default_endpoint":  "https://api.cmpsbl.com/v1/substrate/primitive",
	"offline_capable":   true,
	"capability_hash":   "d56163a4",
	"module_chain_hash": "6932c207",
}

type stage struct {
	Name   string
	Module string
	Verb   string
}

var stages = []stage{
	{Name: "authorize_access", Module: "ACCESS", Verb: "authorize"},
	{Name: "aggregate_analytics", Module: "ANALYTICS", Verb: "aggregate"},
	{Name: "validate_defense", Module: "DEFENSE", Verb: "validate"},
	{Name: "fingerprint_identity", Module: "IDENTITY", Verb: "fingerprint"},
}

func generateExecutionID() string {
	b := make([]byte, 6)
	rand.Read(b)
	return "exec_" + encHex.EncodeToString(b)
}

// StageTrace — per-stage execution record
type StageTrace struct {
	Module        string  `json:"module"`
	Verb          string  `json:"verb"`
	Status        string  `json:"status"`
	DurationMs    float64 `json:"duration_ms"`
	Depth         string  `json:"depth"`
	Validation    string  `json:"validation"`
	StageSource   string  `json:"stage_source"`
	RemoteLatency *float64 `json:"remote_latency_ms,omitempty"`
	LocalLatency  *float64 `json:"local_latency_ms,omitempty"`
}

// ExecutionEnvelope — metadata attached to every result
type ExecutionEnvelope struct {
	ExecutionID          string  `json:"execution_id"`
	BridgeLanguage       string  `json:"bridge_language"`
	BridgeType           string  `json:"bridge_type"`
	RuntimeMode          string  `json:"runtime_mode"`
	WasRemoteAttempted   bool    `json:"was_remote_attempted"`
	WasRemoteUsed        bool    `json:"was_remote_used"`
	UsedFallback         bool    `json:"used_fallback"`
	FallbackReason       string  `json:"fallback_reason,omitempty"`
	ValidationResult     string  `json:"validation_result"`
	HealthScoreAtExec    float64 `json:"health_score_at_execution"`
	ModeBeforeExecution  string  `json:"mode_before_execution"`
	ModeAfterExecution   string  `json:"mode_after_execution"`
	CanonicalVersion     string  `json:"canonical_version"`
	CapabilityHash       string  `json:"capability_hash"`
}

// BridgeResult — normalized bridge output
type BridgeResult struct {
	Success            bool                   `json:"success"`
	Data               map[string]interface{} `json:"data"`
	Error              string                 `json:"error,omitempty"`
	LatencyMs          float64                `json:"latency_ms"`
	Confidence         float64                `json:"confidence"`
	Trace              []StageTrace           `json:"trace"`
	StagesCompleted    int                    `json:"stages_completed"`
	TotalStages        int                    `json:"total_stages"`
	RuntimeMode        string                 `json:"runtime_mode"`
	BridgeType         string                 `json:"bridge_type"`
	ExecutionID        string                 `json:"execution_id"`
	Validated          bool                   `json:"validated"`
	ValidationErrors   []string               `json:"validation_errors"`
	ValidationWarnings []string               `json:"validation_warnings"`
	Degraded           bool                   `json:"degraded"`
	DegradedReasons    []string               `json:"degraded_reasons"`
	Envelope           *ExecutionEnvelope     `json:"envelope"`
}

// healthTracker — lightweight rolling health for canonical endpoint
type healthTracker struct {
	consecutiveSuccesses    int
	consecutiveFailures     int
	totalRemoteAttempts     int
	totalRemoteSuccesses    int
	totalFallbacks          int
	totalValidationFailures int
}

func (h *healthTracker) healthScore() float64 {
	if h.totalRemoteAttempts == 0 { return 50.0 }
	successRate := float64(h.totalRemoteSuccesses) / float64(h.totalRemoteAttempts) * 100
	valPenalty := float64(h.totalValidationFailures) / float64(h.totalRemoteAttempts) * 100
	raw := successRate*0.6 + (100-valPenalty*2)*0.4
	return math.Max(0, math.Min(100, raw))
}

func (h *healthTracker) recordSuccess() {
	h.totalRemoteAttempts++; h.totalRemoteSuccesses++
	h.consecutiveSuccesses++; h.consecutiveFailures = 0
}

func (h *healthTracker) recordFailure() {
	h.totalRemoteAttempts++; h.consecutiveFailures++; h.consecutiveSuccesses = 0
}

func (h *healthTracker) recordValidationFailure() {
	h.totalRemoteAttempts++; h.totalValidationFailures++
	h.consecutiveFailures += 2; h.consecutiveSuccesses = 0
}

func (h *healthTracker) recordFallback() { h.totalFallbacks++ }

func (h *healthTracker) evaluateMode(current string) string {
	if h.consecutiveFailures >= 3 { return "offline" }
	if h.consecutiveSuccesses >= 5 { return "network" }
	if current == "offline" && h.consecutiveSuccesses >= 2 { return "hybrid" }
	if current == "network" && h.consecutiveFailures > 0 { return "hybrid" }
	return current
}

// AdaptiveRateLimitingEngine — CMPSBL® Bridge Adapter
type AdaptiveRateLimitingEngine struct {
	mu             sync.Mutex
	endpoint       string
	runtimeMode    string
	executionCount int
	successCount   int
	health         healthTracker
	forcedMode     string
}

// NewAdaptiveRateLimitingEngine creates a new bridge adapter
func NewAdaptiveRateLimitingEngine(endpoint ...string) *AdaptiveRateLimitingEngine {
	ep := "https://api.cmpsbl.com/v1/substrate/primitive"
	if len(endpoint) > 0 {
		ep = endpoint[0]
	}
	mode := "hybrid"
	if ep == "" {
		mode = "offline"
	}
	return &AdaptiveRateLimitingEngine{endpoint: ep, runtimeMode: mode}
}

// ConfigureEndpoint sets the canonical runtime endpoint
func (b *AdaptiveRateLimitingEngine) ConfigureEndpoint(url string) {
	b.mu.Lock(); defer b.mu.Unlock()
	b.endpoint = url
	if url == "" { b.runtimeMode = "offline" } else { b.runtimeMode = "hybrid" }
}

// RuntimeMode returns the current connectivity mode
func (b *AdaptiveRateLimitingEngine) RuntimeMode() string {
	if b.forcedMode != "" { return b.forcedMode }
	return b.runtimeMode
}

// GetHealthScore returns the current health score (0-100)
func (b *AdaptiveRateLimitingEngine) GetHealthScore() float64 { return b.health.healthScore() }

// GetHealthSnapshot returns full health state
func (b *AdaptiveRateLimitingEngine) GetHealthSnapshot() map[string]interface{} {
	b.mu.Lock(); defer b.mu.Unlock()
	return map[string]interface{}{
		"current_mode": b.RuntimeMode(), "health_score": b.health.healthScore(),
		"consecutive_successes": b.health.consecutiveSuccesses,
		"consecutive_failures": b.health.consecutiveFailures,
		"total_remote_attempts": b.health.totalRemoteAttempts,
		"total_fallbacks": b.health.totalFallbacks,
		"total_validation_failures": b.health.totalValidationFailures,
		"mode_forced": b.forcedMode != "",
	}
}

// ResetHealthState clears health to defaults
func (b *AdaptiveRateLimitingEngine) ResetHealthState() {
	b.mu.Lock(); defer b.mu.Unlock()
	b.health = healthTracker{}
	b.runtimeMode = "hybrid"; b.forcedMode = ""
}

// ForceMode overrides automatic mode switching (test/debug only)
func (b *AdaptiveRateLimitingEngine) ForceMode(mode string) { b.forcedMode = mode }

// ClearForceMode removes mode override
func (b *AdaptiveRateLimitingEngine) ClearForceMode() { b.forcedMode = "" }

func (b *AdaptiveRateLimitingEngine) buildIntegrityPayload() map[string]interface{} {
	return map[string]interface{}{
		"canonicalVersion": BridgeMeta["canonical_version"],
		"bridgeType": "hybrid", "runtimeType": "portable",
		"executionMode": b.RuntimeMode(),
		"capabilityHash": BridgeMeta["capability_hash"],
		"moduleChainHash": BridgeMeta["module_chain_hash"],
		"expectedCJPI": BridgeMeta["cjpi"],
	}
}

// Execute runs the bridge: remote-first, then deterministic local fallback
func (b *AdaptiveRateLimitingEngine) Execute(input map[string]interface{}) BridgeResult {
	b.mu.Lock()
	b.executionCount++
	b.mu.Unlock()

	executionID := generateExecutionID()
	modeBefore := b.RuntimeMode()
	start := time.Now()
	data := make(map[string]interface{})
	for k, v := range input { data[k] = v }
	confidence := 1.0
	trace := make([]StageTrace, 0, len(stages))
	completed := 0
	wasRemoteAttempted := false
	wasRemoteUsed := false
	usedFallback := false
	fallbackReason := ""
	validated := false
	validationErrors := make([]string, 0)
	validationWarnings := make([]string, 0)
	degraded := false
	degradedReasons := make([]string, 0)

	// Attempt remote canonical runtime
	if b.endpoint != "" && b.RuntimeMode() != "offline" {
		wasRemoteAttempted = true
		payload, _ := json.Marshal(map[string]interface{}{
			"name": BridgeMeta["name"], "data": data, "confidence": confidence,
			"integrity": b.buildIntegrityPayload(),
			"meta": map[string]interface{}{"runtimeType": "portable", "version": BridgeMeta["canonical_version"]},
		})
		client := &http.Client{Timeout: 5 * time.Second}
		resp, err := client.Post(b.endpoint, "application/json", bytes.NewReader(payload))
		if err == nil && resp.StatusCode == 200 {
			var result BridgeResult
			if json.NewDecoder(resp.Body).Decode(&result) == nil {
				resp.Body.Close()
				if result.Validated && len(result.ValidationErrors) == 0 {
					b.health.recordSuccess()
					wasRemoteUsed = true
					b.mu.Lock(); b.successCount++; b.mu.Unlock()
					b.runtimeMode = b.health.evaluateMode(b.runtimeMode)
					result.ExecutionID = executionID
					result.Envelope = &ExecutionEnvelope{
						ExecutionID: executionID, BridgeLanguage: "go",
						BridgeType: "hybrid", RuntimeMode: b.RuntimeMode(),
						WasRemoteAttempted: true, WasRemoteUsed: true,
						ValidationResult: "passed",
						HealthScoreAtExec: b.health.healthScore(),
						ModeBeforeExecution: modeBefore,
						ModeAfterExecution: b.RuntimeMode(),
						CanonicalVersion: "14.4.1",
						CapabilityHash: "d56163a4",
					}
					return result
				}
				// Validation failed — degrade, do NOT silently fallback
				b.health.recordValidationFailure()
				degraded = true
				for _, e := range result.ValidationErrors {
					degradedReasons = append(degradedReasons, "Remote validation: "+e)
				}
				validationErrors = result.ValidationErrors
				fallbackReason = "degraded"
			}
			resp.Body.Close()
		} else {
			b.health.recordFailure()
			fallbackReason = "normal"
			if resp != nil { resp.Body.Close() }
		}
	}

	if !wasRemoteUsed {
		usedFallback = true
		if fallbackReason == "" {
			if b.RuntimeMode() == "offline" { fallbackReason = "offline" } else { fallbackReason = "normal" }
		}
		b.health.recordFallback()
	}

	// Deterministic local fallback
	for _, s := range stages {
		stageStart := time.Now()
		data[fmt.Sprintf("%s_result", s.Module)] = map[string]interface{}{
			"module": s.Module, "verb": s.Verb,
			"confidence": confidence, "bridge": "go", "mode": b.RuntimeMode(),
		}
		confidence = math.Min(1.0, confidence+0.02)
		stageDur := float64(time.Since(stageStart).Microseconds()) / 1000.0
		status := "success"
		depth := "fallback"
		valStatus := "skipped"
		if degraded { status = "degraded"; depth = "degraded"; valStatus = "failed" }
		trace = append(trace, StageTrace{
			Module: s.Module, Verb: s.Verb, Status: status,
			DurationMs: stageDur, Depth: depth, Validation: valStatus,
			StageSource: "bridge-fallback", LocalLatency: &stageDur,
		})
		completed++
	}

	b.mu.Lock(); b.successCount++; b.mu.Unlock()
	b.runtimeMode = b.health.evaluateMode(b.runtimeMode)

	envelope := &ExecutionEnvelope{
		ExecutionID: executionID, BridgeLanguage: "go",
		BridgeType: "hybrid", RuntimeMode: b.RuntimeMode(),
		WasRemoteAttempted: wasRemoteAttempted, WasRemoteUsed: wasRemoteUsed,
		UsedFallback: usedFallback, FallbackReason: fallbackReason,
		ValidationResult: func() string { if degraded { return "failed" }; return "skipped" }(),
		HealthScoreAtExec: b.health.healthScore(),
		ModeBeforeExecution: modeBefore, ModeAfterExecution: b.RuntimeMode(),
		CanonicalVersion: "14.4.1", CapabilityHash: "d56163a4",
	}

	return BridgeResult{
		Success: !degraded, Data: data,
		LatencyMs: float64(time.Since(start).Microseconds()) / 1000.0,
		Confidence: confidence, Trace: trace,
		StagesCompleted: completed, TotalStages: len(stages),
		RuntimeMode: b.RuntimeMode(), BridgeType: "hybrid",
		ExecutionID: executionID,
		Validated: validated, ValidationErrors: validationErrors,
		ValidationWarnings: validationWarnings,
		Degraded: degraded, DegradedReasons: degradedReasons,
		Envelope: envelope,
	}
}

// Validate checks capability metadata integrity
func (b *AdaptiveRateLimitingEngine) Validate() bool {
	return BridgeMeta["cjpi"].(int) > 0
}

// Meta returns bridge metadata
func (b *AdaptiveRateLimitingEngine) Meta() map[string]interface{} {
	m := make(map[string]interface{})
	for k, v := range BridgeMeta { m[k] = v }
	m["runtime_mode"] = b.RuntimeMode()
	return m
}

// Stats returns execution statistics
func (b *AdaptiveRateLimitingEngine) Stats() map[string]interface{} {
	b.mu.Lock(); defer b.mu.Unlock()
	rate := 0.0
	if b.executionCount > 0 { rate = float64(b.successCount) / float64(b.executionCount) }
	return map[string]interface{}{
		"name": BridgeMeta["name"], "cjpi": BridgeMeta["cjpi"],
		"bridge_type": BridgeMeta["bridge_type"],
		"runtime_mode": b.RuntimeMode(), "executions": b.executionCount,
		"success_rate": rate, "health_score": b.health.healthScore(),
	}
}
