// Test Suite — Adaptive Rate Limiting Engine
// Auto-generated test harness for CMPSBL® artifact validation
// Run: cargo test

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::HashMap;

    #[test]
    fn test_instantiation() {
        let engine = AdaptiveRateLimitingEngine::new();
        let stats = engine.stats();
        assert_eq!(stats.get("name").unwrap(), "Adaptive Rate Limiting Engine");
    }

    #[test]
    fn test_empty_input() {
        let mut engine = AdaptiveRateLimitingEngine::new();
        let result = engine.execute(HashMap::new());
        assert_eq!(result.total_stages, 4);
        assert!(result.latency_ms >= 0.0);
    }

    #[test]
    fn test_sample_data() {
        let mut engine = AdaptiveRateLimitingEngine::new();
        let input = HashMap::from([
            ("test_key".into(), "test_value".into()),
            ("score".into(), "42".into()),
        ]);
        let result = engine.execute(input);
        assert!(result.success, "Pipeline should succeed: {:?}", result.error);
        assert_eq!(result.stages_completed, result.total_stages);
        assert!(result.confidence > 0.5);
    }

    #[test]
    fn test_statistics() {
        let mut engine = AdaptiveRateLimitingEngine::new();
        engine.execute(HashMap::from([("a".into(), "1".into())]));
        engine.execute(HashMap::from([("b".into(), "2".into())]));
        let stats = engine.stats();
        assert_eq!(stats.get("executions").unwrap(), "2");
    }
}
