`timescale 1ns / 1ps
// ═══════════════════════════════════════════════════════════════
// Testbench — Adaptive Rate Limiting Engine
// Auto-generated validation testbench for CMPSBL® silicon artifact
// Run: iverilog -o tb_adaptive_rate_limiting_engine tb_adaptive_rate_limiting_engine.v adaptive_rate_limiting_engine.v && vvp tb_adaptive_rate_limiting_engine
// ═══════════════════════════════════════════════════════════════

module tb_adaptive_rate_limiting_engine;
    parameter DATA_WIDTH = 32;
    parameter NUM_STAGES = 4;

    reg clk, rst_n, start;
    reg [DATA_WIDTH-1:0] data_in;
    reg data_valid;
    wire done, busy, error;
    wire [DATA_WIDTH-1:0] data_out;
    wire data_ready;
    wire [7:0] confidence;
    wire [31:0] latency_cycles;

    // DUT
    adaptive_rate_limiting_engine #(.DATA_WIDTH(DATA_WIDTH), .NUM_STAGES(NUM_STAGES)) dut (
        .clk(clk), .rst_n(rst_n), .start(start),
        .data_in(data_in), .data_valid(data_valid),
        .data_out(data_out), .data_ready(data_ready),
        .done(done), .busy(busy), .error(error),
        .confidence(confidence), .latency_cycles(latency_cycles)
    );

    // Clock: 100 MHz
    always #5 clk = ~clk;

    integer pass_count = 0;
    integer fail_count = 0;

    task check(input string name, input logic cond);
        if (cond) begin
            $display("[PASS] %s", name);
            pass_count = pass_count + 1;
        end else begin
            $display("[FAIL] %s", name);
            fail_count = fail_count + 1;
        end
    endtask

    initial begin
        $dumpfile("tb_adaptive_rate_limiting_engine.vcd");
        $dumpvars(0, tb_adaptive_rate_limiting_engine);

        // Init
        clk = 0; rst_n = 0; start = 0; data_in = 0; data_valid = 0;
        #20 rst_n = 1;
        #10;

        // Test 1: Basic execution
        $display("\n=== Test 1: Basic Pipeline Execution ===");
        data_in = 32'hDEADBEEF;
        data_valid = 1;
        start = 1;
        #10 start = 0; data_valid = 0;
        
        // Wait for done
        repeat (100) @(posedge clk);
        check("Pipeline completes", done === 1'b1);
        check("No error", error === 1'b0);
        check("Confidence > 0", confidence > 0);
        check("Output produced", data_out !== 0);

        // Test 2: Reset behavior
        $display("\n=== Test 2: Reset Behavior ===");
        rst_n = 0;
        #20 rst_n = 1;
        #10;
        check("Reset clears busy", busy === 1'b0);
        check("Reset clears done", done === 1'b0);

        // Test 3: Different input
        $display("\n=== Test 3: Different Input ===");
        data_in = 32'hCAFEBABE;
        data_valid = 1;
        start = 1;
        #10 start = 0; data_valid = 0;
        repeat (100) @(posedge clk);
        check("Second run completes", done === 1'b1);

        // Summary
        $display("\n═══════════════════════════════════════");
        $display("Results: %0d passed, %0d failed", pass_count, fail_count);
        $display("═══════════════════════════════════════\n");

        $finish;
    end
endmodule
