"""
Test Suite — Constitutional AI Guardian
Auto-generated test harness for CMPSBL® artifact validation
Run: pytest test_constitutional_ai_guardian.py -v
"""

import pytest
from constitutional_ai_guardian import ConstitutionalAIGuardian


class TestConstitutionalAIGuardian:
    def test_instantiation(self):
        engine = ConstitutionalAIGuardian()
        stats = engine.stats
        assert stats["name"] == "Constitutional AI Guardian"
        assert stats["cjpi"] == 100

    def test_empty_input(self):
        engine = ConstitutionalAIGuardian()
        result = engine.execute({})
        assert result.total_stages == 4
        assert result.entry_point == "input"
        assert result.exit_point == "output"
        assert result.latency_ms >= 0

    def test_sample_data(self):
        engine = ConstitutionalAIGuardian()
        result = engine.execute({
            "test_key": "test_value",
            "score": 42,
            "tags": ["alpha", "beta"],
        })
        assert result.success is True
        assert result.stages_completed == result.total_stages
        assert result.confidence > 0.5
        assert len(result.pipeline_trace) == 4

    def test_statistics_tracking(self):
        engine = ConstitutionalAIGuardian()
        engine.execute({"a": 1})
        engine.execute({"b": 2})
        stats = engine.stats
        assert stats["execution_count"] == 2
        assert stats["success_rate"] > 0

    def test_module_chain(self):
        engine = ConstitutionalAIGuardian()
        stats = engine.stats
        assert stats["module_chain"] == ["BRAIN","CORTEX","DEFENSE","GOVERNANCE"]
        assert stats["category"] == "governance"

    def test_reset(self):
        engine = ConstitutionalAIGuardian()
        engine.execute({"x": 1})
        engine.reset()
        assert engine.stats["execution_count"] == 0
