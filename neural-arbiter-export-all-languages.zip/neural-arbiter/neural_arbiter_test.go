// Test Suite — Neural Arbiter
// Auto-generated test harness for CMPSBL® artifact validation
// Run: go test -v ./neural_arbiter/

package neural_arbiter

import (
	"testing"
)

func TestNewNeuralArbiter(t *testing.T) {
	engine := NewNeuralArbiter()
	if engine == nil {
		t.Fatal("Expected non-nil engine")
	}
}

func TestExecuteEmpty(t *testing.T) {
	engine := NewNeuralArbiter()
	result := engine.Execute(map[string]interface{}{})
	if result.TotalStages != 5 {
		t.Errorf("Expected 5 stages, got %d", result.TotalStages)
	}
	if result.EntryPoint != "input" {
		t.Errorf("Expected entry 'input', got '%s'", result.EntryPoint)
	}
}

func TestExecuteSampleData(t *testing.T) {
	engine := NewNeuralArbiter()
	input := map[string]interface{}{
		"test_key": "test_value",
		"score":    42,
	}
	result := engine.Execute(input)
	if !result.Success {
		t.Fatalf("Pipeline failed: %s", result.Error)
	}
	if result.StagesCompleted != result.TotalStages {
		t.Errorf("Expected %d stages completed, got %d", result.TotalStages, result.StagesCompleted)
	}
	if result.Confidence <= 0.5 {
		t.Errorf("Expected confidence > 0.5, got %f", result.Confidence)
	}
}

func TestStats(t *testing.T) {
	engine := NewNeuralArbiter()
	engine.Execute(map[string]interface{}{"a": 1})
	engine.Execute(map[string]interface{}{"b": 2})
	stats := engine.Stats()
	if stats["execution_count"].(int) != 2 {
		t.Errorf("Expected 2 executions, got %v", stats["execution_count"])
	}
}
