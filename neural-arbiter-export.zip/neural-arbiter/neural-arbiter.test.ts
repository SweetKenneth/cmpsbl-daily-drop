/**
 * Test Suite — Neural Arbiter
 * Auto-generated test harness for CMPSBL® artifact validation
 * Run: npx vitest run neural-arbiter.test.ts
 */

import { describe, it, expect } from 'vitest';
import { NeuralArbiter } from './neural-arbiter';

describe('NeuralArbiter', () => {
  it('should instantiate with default config', () => {
    const engine = new NeuralArbiter();
    expect(engine).toBeDefined();
    const stats = engine.getStats();
    expect(stats.name).toBe('Neural Arbiter');
    expect(stats.cjpi).toBe(100);
  });

  it('should execute pipeline with empty input', async () => {
    const engine = new NeuralArbiter();
    const result = await engine.execute({});
    expect(result.totalStages).toBe(5);
    expect(result.entryPoint).toBe('input');
    expect(result.exitPoint).toBe('output');
    expect(result.latencyMs).toBeGreaterThanOrEqual(0);
  });

  it('should execute pipeline with sample data', async () => {
    const engine = new NeuralArbiter();
    const result = await engine.execute({
      test_key: 'test_value',
      score: 42,
      tags: ['alpha', 'beta'],
    });
    expect(result.success).toBe(true);
    expect(result.stagesCompleted).toBe(result.totalStages);
    expect(result.confidence).toBeGreaterThan(0.5);
    expect(result.pipelineTrace.length).toBe(5);
  });

  it('should track execution statistics', async () => {
    const engine = new NeuralArbiter();
    await engine.execute({ a: 1 });
    await engine.execute({ b: 2 });
    const stats = engine.getStats();
    expect(stats.executionCount).toBe(2);
    expect(stats.successRate).toBeGreaterThan(0);
    expect(stats.avgLatencyMs).toBeGreaterThan(0);
  });

  it('should report module chain in stats', () => {
    const engine = new NeuralArbiter();
    const stats = engine.getStats();
    expect(stats.moduleChain).toEqual(["ANALYTICS","BRAIN","CONSCIENCE","GOVERNANCE","SOVEREIGN"]);
    expect(stats.category).toBe('governance');
  });

  it('should reset statistics', async () => {
    const engine = new NeuralArbiter();
    await engine.execute({ x: 1 });
    engine.reset();
    const stats = engine.getStats();
    expect(stats.executionCount).toBe(0);
  });
});
