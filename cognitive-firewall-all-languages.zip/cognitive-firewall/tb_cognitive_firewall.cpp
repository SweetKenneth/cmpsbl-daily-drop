// SystemC Testbench — Cognitive Firewall
// Auto-generated validation testbench for CMPSBL® artifact
// Compile: g++ -I$SYSTEMC_HOME/include -L$SYSTEMC_HOME/lib -lsystemc -o tb_cognitivefirewall tb_cognitivefirewall.cpp cognitivefirewall.cpp

#include <systemc.h>
#include <cassert>
#include <iostream>

// Include the DUT
#include "cognitivefirewall.cpp"

SC_MODULE(CognitiveFirewall_TB) {
    sc_clock clk;
    sc_signal<bool> rst_n, start, done, busy;
    sc_signal<sc_uint<32>> data_in, data_out;
    sc_signal<sc_uint<8>> confidence;

    CognitiveFirewall* dut;

    void run_tests() {
        // Reset
        rst_n.write(false);
        wait(3, SC_NS);
        rst_n.write(true);
        wait(1, SC_NS);

        std::cout << "[TEST 1] Basic pipeline execution" << std::endl;
        data_in.write(0xDEADBEEF);
        start.write(true);
        wait(1, SC_NS);
        start.write(false);

        for (int i = 0; i < 8; i++) wait(1, SC_NS);

        assert(done.read() == true);
        std::cout << "  Output:     0x" << std::hex << data_out.read() << std::endl;
        std::cout << "  Confidence: " << std::dec << confidence.read() << std::endl;
        std::cout << "  [PASS]" << std::endl;

        // Reset test
        std::cout << "[TEST 2] Reset clears state" << std::endl;
        rst_n.write(false);
        wait(2, SC_NS);
        rst_n.write(true);
        wait(1, SC_NS);
        assert(busy.read() == false);
        assert(done.read() == false);
        std::cout << "  [PASS]" << std::endl;

        // Different input
        std::cout << "[TEST 3] Different input" << std::endl;
        data_in.write(0xCAFEBABE);
        start.write(true);
        wait(1, SC_NS);
        start.write(false);
        for (int i = 0; i < 8; i++) wait(1, SC_NS);
        assert(done.read() == true);
        std::cout << "  [PASS]" << std::endl;

        std::cout << "\n=== All tests passed ===" << std::endl;
        sc_stop();
    }

    SC_CTOR(CognitiveFirewall_TB) : clk("clk", 1, SC_NS) {
        dut = new CognitiveFirewall("dut");
        dut->clk(clk);
        dut->rst_n(rst_n);
        dut->start(start);
        dut->data_in(data_in);
        dut->data_out(data_out);
        dut->done(done);
        dut->busy(busy);
        dut->confidence_out(confidence);

        SC_THREAD(run_tests);
    }
    ~CognitiveFirewall_TB() { delete dut; }
};

int sc_main(int argc, char* argv[]) {
    CognitiveFirewall_TB tb("tb");
    sc_start();
    return 0;
}
