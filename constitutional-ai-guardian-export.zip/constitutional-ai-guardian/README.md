# Constitutional AI Guardian

> **CMPSBL® S-Tier Crown Jewel** — Rank #0 | Module: BRAIN

Enforces constitutional constraints on autonomous behavior with graduated intervention

## Exported Files

- `constitutional-ai-guardian.ts` — TypeScript (Standalone Module)
- `constitutional-ai-guardian.test.ts` — TypeScript (Standalone Module)
- `LICENSE` — TypeScript (Standalone Module)
- `LICENSE.html` — TypeScript (Standalone Module)
- `PIPELINE-DETAILS.html` — TypeScript (Standalone Module)
- `README.html` — TypeScript (Standalone Module)
- `Makefile` — TypeScript (Standalone Module)
- `package.json` — TypeScript (Standalone Module)

## Languages

TypeScript

## Architecture — One Runtime, Many Bridges

This bundle follows the **CMPSBL® One Runtime, Many Bridges** architecture:

- **TypeScript**: Contains the full canonical Mini-Runtime™ (CJPI, tiering, FSM, saga)
- **All other languages**: Bridge adapters that route execution to the canonical runtime
  when configured, with deterministic local fallback for offline operation

### Execution Integrity

Every bridge request includes an **integrity payload** validated by the canonical runtime:
- `capabilityHash` — stable hash of capability identity (name + chain + category)
- `moduleChainHash` — independent chain tamper detection
- `canonicalVersion` — version compatibility check
- `expectedCJPI` — score consistency verification

If validation fails, execution is marked **degraded** — never silently masked.

### Runtime Health & Mode Switching

Bridges maintain a rolling **health score** (0–100) that governs automatic mode switching:
- **network**: Canonical runtime is healthy and stable (≥5 consecutive successes)
- **hybrid**: Remote usable but not fully trusted (default, or after intermittent failures)
- **offline**: Remote unavailable, invalid, or too unhealthy (≥3 consecutive failures)

Validation failures are weighted **2×** more heavily than transport failures.
Mode transitions are recorded, inspectable, and never hidden.

### Key Files

| File | Purpose |
|------|---------|
| `standalone-runtime.ts` | CMPSBL® Mini-Runtime™ Engine — the single canonical runtime |
| `*.py / *.go / *.rs / etc` | Bridge adapters — metadata + integrity + remote-first + fallback |
| `Makefile` | Build & test commands for every included language |
| `LICENSE` | CMPSBL® Proprietary License |
| `*_test.*` / `tb_*.*` | Test harnesses / testbenches for validation |

### Execution Modes

All bridge adapters operate in one of three modes:
- **network**: Canonical runtime remote/central (when configured + stable)
- **hybrid**: Try canonical runtime first, then deterministic fallback (default)
- **offline**: Deterministic local fallback only (no endpoint or unavailable)

### Fallback Classification

Fallback behavior is integrity-aware:
- **normal**: Remote unavailable but metadata trusted
- **degraded**: Remote validation/integrity mismatch or malformed response
- **offline**: Endpoint intentionally unset or offline mode configured

> **TL;DR:** TypeScript exports include the real runtime. All other language exports
> are thin bridge adapters that validate integrity, track health, and delegate to
> the canonical runtime when available. Degraded execution is explicit, never hidden.

> **Note:** The Discovery Engine is a substrate-exclusive capability and is not included
> in any export. For discovery, use the CMPSBL® Substrate at https://cmpsbl.com

## Quick Start (Software)

### TypeScript/Node
```typescript
import { ConstitutionalAIGuardian } from './constitutional-ai-guardian';
const engine = new ConstitutionalAIGuardian();
const result = await engine.execute({ key: 'value' });
```

### Python
```python
from constitutional_ai_guardian import ConstitutionalAIGuardian
engine = ConstitutionalAIGuardian()
result = engine.execute({"key": "value"})
```

### Using the CMPSBL® Mini-Runtime™ Engine (Advanced)
```typescript
import { createRuntime } from './standalone-runtime';

const runtime = createRuntime();
// Use the runtime for CJPI scoring, FSM, and pipeline orchestration
```

## Build & Test

Use the included `Makefile` for all build and test commands:

```bash
make ts-test       # Run TypeScript tests (Vitest)
make py-test       # Run Python tests (pytest)
make go-test       # Run Go tests
make verilog-sim   # Run Verilog simulation
make systemc-run   # Run SystemC testbench
```

## License

CMPSBL® Proprietary. All rights reserved.
